package com.dev.instagramfocus

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Color
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout
import android.widget.TextView
import kotlin.math.abs

/**
 * Instagram Focus Mode prototype.
 *
 * Uses Android AccessibilityService + TYPE_ACCESSIBILITY_OVERLAY.
 * Instagram UI labels/structure can change, so detection may need maintenance.
 */
class FocusAccessibilityService : AccessibilityService() {

    companion object {
        private const val INSTAGRAM = "com.instagram.android"
        private const val NAV_HEIGHT_DP = 88
        private const val PROFILE_HEADER_DP = 300
        private const val SHARED_REEL_WINDOW_MS = 2500L
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private var overlay: FrameLayout? = null
    private var mode = Mode.NONE
    private var lastSharedReelAt = 0L
    private var downX = 0f
    private var downY = 0f
    private var downTime = 0L

    private enum class Mode { NONE, FEED_LOCK, STORY_HORIZONTAL, PROFILE_LOCK, BLOCK_SCREEN }

    override fun onServiceConnected() {
        super.onServiceConnected()
        serviceInfo = serviceInfo.apply {
            notificationTimeout = 20
            flags = flags or
                android.accessibilityservice.AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                android.accessibilityservice.AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        if (event.packageName?.toString() != INSTAGRAM) {
            removeOverlay()
            return
        }

        val blob = buildString {
            event.text?.forEach { append(it).append(' ') }
            event.contentDescription?.let { append(it).append(' ') }
            append(event.className ?: "")
        }.lowercase()

        if (blob.contains("sent you a reel") ||
            blob.contains("shared a reel") ||
            blob.contains("reel with you") ||
            blob.contains("reel sent")) {
            lastSharedReelAt = android.os.SystemClock.uptimeMillis()
        }

        if (event.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED) {
            val age = android.os.SystemClock.uptimeMillis() - lastSharedReelAt
            if (age in 0..SHARED_REEL_WINDOW_MS) {
                lastSharedReelAt = 0L
                openDirectMessages()
                return
            }
        }

        when (event.eventType) {
            AccessibilityEvent.TYPE_VIEW_CLICKED,
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED,
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
            AccessibilityEvent.TYPE_VIEW_SCROLLED -> refreshOverlay(blob)
        }
    }

    override fun onInterrupt() = removeOverlay()

    override fun onDestroy() {
        removeOverlay()
        super.onDestroy()
    }

    private fun refreshOverlay(blob: String) {
        mainHandler.post {
            mode = when {
                isExploreOrReelsTab(blob) -> Mode.BLOCK_SCREEN
                looksLikeOtherProfile(blob) -> Mode.PROFILE_LOCK
                looksLikeStory(blob) -> Mode.STORY_HORIZONTAL
                else -> Mode.FEED_LOCK
            }
            renderOverlay(messageFor(mode))
        }
    }

    private fun isExploreOrReelsTab(blob: String): Boolean =
        blob.contains("reels") ||
        blob.contains("explore") ||
        blob.contains("search and explore") ||
        blob.contains("reels and videos")

    private fun looksLikeOtherProfile(blob: String): Boolean {
        val profileSignals = blob.contains("followers") &&
            (blob.contains("following") || blob.contains("posts"))
        val ownSignals = blob.contains("edit profile") ||
            blob.contains("professional dashboard") ||
            blob.contains("share profile")
        return profileSignals && !ownSignals
    }

    private fun looksLikeStory(blob: String): Boolean =
        blob.contains("story") || blob.contains("stories") || blob.contains("close friends")

    private fun messageFor(current: Mode): String? = when (current) {
        Mode.BLOCK_SCREEN -> "Stay connected, not endlessly scrolling."
        Mode.PROFILE_LOCK -> "Profile posts and reels are hidden in Focus Mode."
        Mode.STORY_HORIZONTAL -> "Story mode: horizontal swipe only."
        else -> null
    }

    private fun renderOverlay(message: String?) {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val density = resources.displayMetrics.density
        val navHeight = (NAV_HEIGHT_DP * density).toInt()
        val profileHeader = (PROFILE_HEADER_DP * density).toInt()
        val screenHeight = resources.displayMetrics.heightPixels
        val contentHeight = (screenHeight - navHeight).coerceAtLeast(1)

        if (overlay == null) {
            overlay = FrameLayout(this).apply {
                setBackgroundColor(Color.TRANSPARENT)
                isClickable = true
                setOnTouchListener { _, event -> handleOverlayTouch(event) }
            }
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                contentHeight,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                android.graphics.PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.START
            wm.addView(overlay, lp)
        } else {
            val params = overlay!!.layoutParams as WindowManager.LayoutParams
            if (params.height != contentHeight) {
                params.height = contentHeight
                wm.updateViewLayout(overlay, params)
            }
        }

        val root = overlay ?: return
        root.removeAllViews()

        // The overlay itself ends above Instagram's bottom navigation.
        // Therefore the bottom taskbar remains visible and interactive.
        when (mode) {
            Mode.BLOCK_SCREEN -> {
                addFullMask(root, Color.argb(248, 10, 14, 26), message)
            }
            Mode.PROFILE_LOCK -> {
                // Leave the profile header visible; hide the highlights/posts/reels region.
                val mask = FrameLayout(this).apply {
                    setBackgroundColor(Color.argb(248, 10, 14, 26))
                }
                val lp = FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    (contentHeight - profileHeader).coerceAtLeast(1)
                )
                lp.topMargin = profileHeader.coerceAtMost(contentHeight - 1)
                root.addView(mask, lp)
                addCenteredMessage(root, "Profile posts and reels are hidden in Focus Mode.", lp.topMargin)
            }
            Mode.STORY_HORIZONTAL -> {
                // Transparent blocker: only horizontal swipes are replayed to Instagram.
                // This also blocks vertical movement while preserving the bottom nav.
            }
            Mode.FEED_LOCK, Mode.NONE -> Unit
        }
    }

    private fun addFullMask(root: FrameLayout, color: Int, message: String?) {
        val mask = FrameLayout(this).apply { setBackgroundColor(color) }
        root.addView(mask, FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        if (message != null) addCenteredMessage(root, message, 0)
    }

    private fun addCenteredMessage(root: FrameLayout, message: String, top: Int) {
        val tv = TextView(this).apply {
            text = message
            textSize = 20f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(50, 30, 50, 30)
        }
        val lp = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        )
        lp.topMargin = top
        root.addView(tv, lp)
    }

    private fun handleOverlayTouch(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.rawX
                downY = event.rawY
                downTime = android.os.SystemClock.uptimeMillis()
                return true
            }
            MotionEvent.ACTION_UP -> {
                val x = event.rawX
                val y = event.rawY
                val dx = x - downX
                val dy = y - downY
                val duration = (android.os.SystemClock.uptimeMillis() - downTime)
                    .coerceIn(80L, 700L)

                when (mode) {
                    Mode.STORY_HORIZONTAL -> {
                        if (abs(dx) > abs(dy) && abs(dx) > 35f) {
                            replaySwipe(downX, downY, x, y, duration)
                        } else if (abs(dx) < 18f && abs(dy) < 18f) {
                            replayTap(x, y)
                        }
                    }
                    Mode.FEED_LOCK, Mode.PROFILE_LOCK -> {
                        if (abs(dx) < 18f && abs(dy) < 18f) replayTap(x, y)
                    }
                    Mode.BLOCK_SCREEN, Mode.NONE -> Unit
                }
                return true
            }
        }
        return true
    }

    private fun replayTap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 40)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    private fun replaySwipe(x1: Float, y1: Float, x2: Float, y2: Float, duration: Long) {
        val path = Path().apply {
            moveTo(x1, y1)
            lineTo(x2, y2)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, duration)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    private fun openDirectMessages() {
        try {
            val intent = packageManager.getLaunchIntentForPackage(INSTAGRAM) ?: return
            intent.flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK or
                android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP
            intent.data = android.net.Uri.parse("https://www.instagram.com/direct/inbox/")
            startActivity(intent)
        } catch (_: Exception) {
            // Keep the focus layer alive if Instagram rejects the deep link.
        }
    }

    private fun removeOverlay() {
        mainHandler.post {
            overlay?.let {
                try {
                    (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it)
                } catch (_: Exception) {
                }
            }
            overlay = null
            mode = Mode.NONE
        }
    }
}
